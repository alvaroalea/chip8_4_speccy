#pragma once
#include "stdafx.h"

void FillDebugData(HWND hDebugWnd);
void ShowDebugDlg();
INT_PTR CALLBACK DebugWnd(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam);
void RunToOp(HWND hDlg,uint TargetPC);
void SkipToOp(uint TargetPC);
void NextOp(WORD OpCode, uint TargetPC);
bool IsValidOp(WORD OpCode);
void AddOps(HWND hDebugWnd);
char* TranslateOp(WORD OpCode);
void SaveState(char* strFileName);
void LoadState(char* strFileName);
void AddOps();
void PressKey(HWND hDlg);
void CreateBreakPoint(HWND hDlg, uint TargetPC);
void StepOut();
void SetRegisters();
int HexToDec(char* hex);

DWORD WINAPI RunToOpThread(LPVOID lParam);
DWORD WINAPI InputThread(LPVOID lParam);
DWORD WINAPI GotoBreakPoint(LPVOID lParam);