#pragma once
#include "stdafx.h"

extern __int64 signature;
extern byte screen[0x2000+1];

inline void PONG_HACK(int x, int y)
{
	if (signature == 0x0c6d3f6c0c6b026a) // Pong
	{
		if (x == 0x02)
		{
			for (int i=0; i<32; i++)
				screen[2+(i*64)] = 0;
		} else if (x == 0x3F) {
			for (int i=0; i<32; i++)
				screen[0x3F+(i*64)] = 0;
		}
	}
}

inline void PONG2_HACK(int x, int y)
{
	if (signature == 0x0c6d3f6c0c6bfc22) // Pong 2
	{
		if (x == 0x00)
		{
			for (int i=0; i<32; i++)
				screen[(i*64)] = 0;
		} else if (x == 0x3F) {
			for (int i=0; i<32; i++)
				screen[0x3F+(i*64)] = 0;
		}
	}
}