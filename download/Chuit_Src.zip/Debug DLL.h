#pragma once

#ifdef _DEBUG
void __cdecl _TRACE(const char* text);
void __cdecl ASSERT_(bool exp);
//void __cdecl _DEBUGTRACE(const char* text);
#endif