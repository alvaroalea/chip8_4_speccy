//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Chuit.rc
//
#define IDC_DELAYTIMER                  120
#define IDC_SOUNDTIMER                  121
#define IDC_OPCODE                      122
#define IDC_CHIP8_ACCELERATOR           143
#define IDR_BREAKPOINTS                 144
#define IDD_OPTIONS                     144
#define ID_BREAKPOINTS_SET              145
#define ID_BREAKPOINTS_GOTO             146
#define IDR_STATES                      147
#define ID_STATES_SAVE                  148
#define ID_STATES_LOAD                  149
#define IDR_OPCODES                     150
#define ID_OPCODES_RUNTO                151
#define ID_OPCODES_SKIPTO               152
#define ID_OPCODES_NEXT                 153
#define IDR_STEP                        154
#define ID_STEP_IN                      155
#define ID_STEP_OUT                     156
#define ID_STEP_OVER                    157
#define IDC_V0                          1001
#define IDC_V1                          1002
#define IDC_V2                          1003
#define IDC_V3                          1004
#define IDC_V4                          1005
#define IDC_V5                          1006
#define IDC_V6                          1007
#define IDC_V7                          1008
#define IDC_V8                          1009
#define IDC_V9                          1010
#define IDC_V10                         1011
#define IDC_V11                         1012
#define IDC_V12                         1013
#define IDC_V13                         1014
#define IDC_V14                         1015
#define IDC_V15                         1016
#define IDC_SP                          1017
#define IDC_PC                          1018
#define IDC_I                           1019
#define IDC_OPCODES                     1020
#define IDC_OK                          1021
#define IDC_BREAKPOINTS                 1021
#define IDC_STEP                        1022
#define IDC_STEPNEXT                    1023
#define IDC_STATES                      1023
#define IDC_NODEBUG                     1024
#define IDC_OPS                         1025
#define IDC_NEXTOP                      1026
#define IDC_RUNTOOP                     1027
#define IDC_SYNCOPS                     1027
#define IDC_SKIPTOOP                    1028
#define IDC_DATA                        1028
#define IDC_CHANGEPIXCOLOR              1028
#define IDC_SAVESTATE                   1029
#define IDC_REGDELAY                    1029
#define IDC_LOADSTATE                   1030
#define IDC_CANCEL                      1031
#define IDC_PRESSKEY                    1032
#define IDC_REGDELAY_NUM                1032
#define IDC_CURCOLOR_NUM                1033
#define IDC_PIXELCOLOR                  1034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
