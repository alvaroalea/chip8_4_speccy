The MS-Windows version of Vision-8 was build using
Borland C++ Builder 1.0. To compile it, load Vision8.mak
into the IDE and build it.

