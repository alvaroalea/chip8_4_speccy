#pragma once
#include "stdafx.h"
//#include "..\Dll\DirectX\DirectX.h"
#include <d3d9.h>
#include <dxerr9.h>
#include <vector>
using namespace std;

#define D3DFVF_CUSTOMVERTEX D3DFVF_XYZRHW|D3DFVF_DIFFUSE
struct CUSTOMVERTEX
{
    FLOAT x, y, z, rhw; // The transformed position for the vertex.
    DWORD color;        // The vertex color.
};

extern IDirect3DDevice9* pd3dDevice;

bool CheckInfo(const D3DCAPS9& info);
void DestroyD3D();
void RenderScreen(int* _pixels = NULL,int number = 0);
bool InitD3D();
inline void InitFillerVertices(CUSTOMVERTEX* pFiller,
							   CUSTOMVERTEX* pFiller2);
int InitScreenVertices(CUSTOMVERTEX* pVertices,int* _pixels,int number);
void UpdateInfo();
void RenderText(char* text,byte flags,int fontindex=0,DWORD dwColor = 0);
DWORD WINAPI DrawTextCallback(LPVOID lParam);
void DrawTextCallbackAdvanced(DWORD& dwColor, int index);
//bool CreateVertex();

const int QUIT_EMULATOR = 0x80;
const int USE_COLOR = 0x40;