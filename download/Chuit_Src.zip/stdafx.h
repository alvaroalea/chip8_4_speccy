// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#define _WIN32_WINNT 0x0500
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
// Windows Header Files:
#include <windows.h>

// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

// TODO: reference additional headers your program requires here
#include "..\Dll\D3DFont\D3DFontExports.h"

extern bool bOnlyOpcodes;
extern bool bMonitorDrawOpcode;
extern bool bMonitorRegisterI;
extern bool bDebugOutput;

#pragma warning (disable: 4995 4005) //'_OLD_IOSTREAMS_ARE_DEPRECATED': name was marked as #pragma deprecated
#include "resource.h"
#include "..\Dll\Debug DLL\Debug DLL.h"
#define emu_title "Chuit"
//#ifdef _DEBUG
//	#define TRACE(x) if (!bOnlyOpcodes) _TRACE(x)
//	#define DEBUGTRACE _TRACE
//	#define ASSERT ASSERT_
//	#define DRAWTRACE(x) if (bMonitorDrawOpcode) _TRACE(x)
//	void inline ITRACE(char* place,DWORD dwOpcode,unsigned int I)
//	{
//		if (bMonitorRegisterI)
//		{
//			char msg[100];
//			wsprintf(msg,"%s: I register changed! Retrieving data to store in I from register %X. New value: 0x%X\n",place,(dwOpcode&0x0F00)>>8,I);
//			DEBUGTRACE(msg);
//		}
//	}
//	void inline CPUTRACE(DWORD dwOpcode) 
//	{
//		if (bDebugOutput)
//		{
//			char msg[100];
//			wsprintf(msg,"CPU: Executing opcode 0x%0.4X...\n",dwOpcode);
//			_TRACE(msg);
//		}
//	}
//	//void inline wstracef(char* text, ...)
//	//{
//	//	char msg[100];
//	//	va_start
//	//	wsprintf(msg,text,...);
//	//	_TRACE(msg);
//	//}
//#else
	#define ITRACE
	#define DRAWTRACE
	#define DEBUGTRACE
	#define CPUTRACE
	#define TRACE
	#define Break()
//#endif
#define KeyPressed(key) key & 0x80
typedef unsigned int uint;
typedef unsigned char byte;
#pragma warning (default: 4005)
#define safe_release(p) if (p) p->Release(); p = NULL;