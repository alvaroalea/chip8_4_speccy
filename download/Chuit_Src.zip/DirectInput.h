#pragma once
#define DIRECTINPUT_VERSION 0x0800

#include "stdafx.h"
#include <dinput.h>
#include <dxerr9.h>
#include <DInputExports.h>

bool InitDInput();
void DestroyDInput();
int GetKeyboardPress();
inline void GetKeyboardState();
void ClearKeys();
bool AddCallback(const DIDEVICEINSTANCE* pdidi);
int CheckKeyRegisters();

struct __UserInput
{
	KEY kLeft;
	KEY kRight;
	KEY kUp;
	KEY kDown;
	KEY bStart;
    KEY bQuit;
	
	KEY button[17];

	KEY bStepIn;
	KEY bStepOver;
	KEY bStepOut;
};

extern bool keys[16];
extern bool bExit;

inline void GetKeyboardState()
{
	__UserInput result;
	ZeroMemory(&result,sizeof(result));
	DI_GetBufferedData(&result,NULL,false);

	for (int i=0; i<16; i++)
	{
		if (result.button[i] & 0x80) keys[i] = true;
		if (result.button[i] & 0x40) keys[i] = false;
	}
	if (result.bQuit & 0x80) bExit = true;
}
