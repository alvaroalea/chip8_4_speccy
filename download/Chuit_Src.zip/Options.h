#pragma once
#include <windows.h>
#include "resource.h"

void ShowOptionsDlg();
INT_PTR CALLBACK OptionsProc(
  HWND hwndDlg,  // handle to dialog box
  UINT uMsg,     // message
  WPARAM wParam, // first message parameter
  LPARAM lParam  // second message parameter
);
