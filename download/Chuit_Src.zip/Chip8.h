#pragma once
extern bool bExtendedScreen;

inline int screen_width()
{
	if (bExtendedScreen)
		return 128;
	else
		return 64;
}

inline int screen_height()
{
	if (bExtendedScreen)
		return 64;
	else
		return 32;
}