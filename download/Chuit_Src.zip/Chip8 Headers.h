#pragma once

const int Chip8FontAddress = 0x00; //0xF10;
const int SChip8FontAddress = 0x80; //0xF60

enum check_type
{
	type_offset,
	type_opcode,
	type_jumpcheck
};

// Function defines
bool InitEmu(char* file);
void Shutdown();
DWORD WINAPI EmulationThread(LPVOID lParam);
void cpu();
void UnknownInstruction();
void valid_addr_or_op(uint offset,check_type type);
bool LoadRom(char* file);
bool CloseRom();
DWORD WINAPI EmulationThread(LPVOID lParam);